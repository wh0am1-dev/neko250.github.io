package com.github.neko250.ui;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.utils.I18NBundle;
import com.github.czyzby.lml.annotation.LmlAction;
import com.github.czyzby.lml.parser.action.ActionContainer;
import com.github.czyzby.lml.util.LmlUtilities;

import java.util.Locale;

// here go all the global actions for the app
// use onclick="actions.action" to trigger any of them
public class Actions implements ActionContainer {
    private final GdxUI app = (GdxUI) Gdx.app.getApplicationListener();

    @LmlAction("setLocale")
    public void setLocale(final Actor actor) {
        final String localeId = LmlUtilities.getActorId(actor);
        final I18NBundle currentBundle = app.getParser().getData().getDefaultI18nBundle();

        if (currentBundle.getLocale().getLanguage().equalsIgnoreCase(localeId))
            return;

        app.getParser().getData().setDefaultI18nBundle(I18NBundle.createBundle(Gdx.files.internal("i18n/bundle"), new Locale(localeId)));
        app.reloadViews();
    }
}
