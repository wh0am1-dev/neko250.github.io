package com.github.neko250.ui.views;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.github.czyzby.lml.parser.impl.AbstractLmlView;
import com.github.neko250.ui.GdxUI;

public class ChangeLanguageView extends AbstractLmlView {
    public ChangeLanguageView() {
        super(GdxUI.newStage());
    }

    @Override
    public FileHandle getTemplateFile() {
        return Gdx.files.internal("views/changeLanguage.lml");
    }

    @Override
    public String getViewId() {
        return "changeLanguage";
    }
}
