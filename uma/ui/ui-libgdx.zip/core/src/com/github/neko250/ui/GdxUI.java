package com.github.neko250.ui;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.I18NBundle;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.github.czyzby.kiwi.util.gdx.asset.Disposables;
import com.github.czyzby.lml.parser.LmlParser;
import com.github.czyzby.lml.util.LmlApplicationListener;
import com.github.czyzby.lml.vis.util.VisLml;
import com.github.neko250.ui.views.ChangeLanguageView;
import com.github.neko250.ui.views.CompassView;
import com.github.neko250.ui.views.MainView;
import com.kotcrab.vis.ui.VisUI;

public class GdxUI extends LmlApplicationListener {
    public static final int WIDTH = 1280;
    public static final int HEIGHT = 720;

    private Batch batch;

    @Override
    public void create() {
        VisUI.load(VisUI.SkinScale.X2);
        batch = new SpriteBatch();
        super.create();
        addClassAliases();
        setView(CompassView.class);
        CompassView compass = (CompassView) getView(CompassView.class);
        compass.reload();

        saveDtdSchema(Gdx.files.local("lml.dtd"));
    }

    private void addClassAliases() {
        addClassAlias("mainView", MainView.class);
        addClassAlias("changeLanguageView", ChangeLanguageView.class);
        addClassAlias("compassView", CompassView.class);
    }

    /** @return application's only {@link Batch}. */
    public Batch getBatch() {
        return batch;
    }

    /** @return a new customized {@link Stage} instance. */
    public static Stage newStage() {
        GdxUI app = (GdxUI) Gdx.app.getApplicationListener();
        return new Stage(new FitViewport(WIDTH, HEIGHT), app.getBatch());
    }

    @Override
    public void dispose() {
        super.dispose();
        Disposables.disposeOf(batch);
        VisUI.dispose();
    }

    @Override
    protected LmlParser createParser() {
        return VisLml.parser().actions("actions", Actions.class).i18nBundle(I18NBundle.createBundle(Gdx.files.internal("i18n/bundle"))).build();
    }
}
