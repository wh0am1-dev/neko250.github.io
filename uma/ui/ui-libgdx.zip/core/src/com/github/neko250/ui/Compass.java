package com.github.neko250.ui;

import java.awt.*;
import java.io.File;
import java.util.LinkedList;
import java.util.List;

public class Compass {
    public static final boolean DEBUG = true;
    private File dir;

    public Compass() {
        dir = new File(System.getProperty("user.home"));
    }

    public File getDir() {
        return dir;
    }

    public List<File> lsa() {
        File[] tmp = dir.listFiles();
        List<File> ans = new LinkedList<File>();

        for (int i = 0; i < tmp.length; i++)
            ans.add(tmp[i]);

        return ans;
    }

    public List<File> ls() {
        List<File> ans = lsa();

        for (int i = 0; i < ans.size(); i++)
            if (ans.get(i).isHidden())
                ans.remove(i);

        return ans;
    }

    public List<String> lsaNames() {
        List<String> ans = new LinkedList<String>();
        List<File> tmp = lsa();

        for (int i = 0; i < tmp.size(); i++)
            ans.add(tmp.get(i).getName());

        return ans;
    }

    public List<String> lsNames() {
        List<String> ans = new LinkedList<String>();
        List<File> tmp = ls();

        for (int i = 0; i < tmp.size(); i++)
            ans.add(tmp.get(i).getName());

        return ans;
    }

    public boolean cd(String path) {
        if (path == null) return false;

        if (path.equals("..")) {
            if (dir.getAbsolutePath().equals(System.getProperty("user.home")))
                return false;

            dir = dir.getParentFile();
            return true;
        } else if (lsNames().contains(path)) {
            File tmp = new File(dir.getAbsolutePath() + System.getProperty("file.separator") + path);

            if (tmp.isDirectory()) {
                dir = tmp;
                return true;
            }
        }

        return false;
    }

    public boolean rm(String path) {
        if (path == null) return false;
        if (!lsNames().contains(path)) return false;

        File tmp = new File(dir.getAbsolutePath() + System.getProperty("file.separator") + path);
        if (DEBUG) if (!tmp.getAbsolutePath().contains("/Users/neko250/Desktop/tests/sandbox")) return false;

        return tmp.delete();
    }

    public boolean open(String path) {
        if (path == null) return false;
        if (!lsNames().contains(path)) return false;

        File file = new File(dir.getAbsolutePath() + System.getProperty("file.separator") + path);

        try {
            if (OSDetector.isWindows()) {
                Runtime.getRuntime().exec(new String[]{"rundll32", "url.dll,FileProtocolHandler", file.getAbsolutePath()});
                return true;
            } else if (OSDetector.isLinux() || OSDetector.isMac()) {
                Runtime.getRuntime().exec(new String[]{"/usr/bin/open", file.getAbsolutePath()});
                return true;
            } else if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(file);
                return true;
            } else {
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }
}
