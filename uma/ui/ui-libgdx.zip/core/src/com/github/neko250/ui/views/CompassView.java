package com.github.neko250.ui.views;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Tree;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.github.czyzby.lml.annotation.LmlActor;
import com.github.czyzby.lml.parser.impl.AbstractLmlView;
import com.github.neko250.ui.Compass;
import com.github.neko250.ui.GdxUI;
import com.kotcrab.vis.ui.layout.GridGroup;
import com.kotcrab.vis.ui.widget.VisLabel;
import com.kotcrab.vis.ui.widget.VisTextButton;
import com.kotcrab.vis.ui.widget.VisTextField;
import com.kotcrab.vis.ui.widget.VisTree;

import java.io.File;

public class CompassView extends AbstractLmlView {
    @LmlActor("tree")
    private VisTree tree;
    @LmlActor("path")
    private VisTextField path;
    @LmlActor("board")
    private GridGroup board;

    private Compass compass;

    public CompassView() {
        super(GdxUI.newStage());
        compass = new Compass();
    }

    @Override
    public FileHandle getTemplateFile() {
        return Gdx.files.internal("views/compass.lml");
    }

    @Override
    public String getViewId() {
        return "compass";
    }

    public void reload() {
        tree.clearChildren();
        board.clearChildren();
        path.setText(compass.getDir().getAbsolutePath());

        tree.add(new Tree.Node(new VisLabel("." + System.getProperty("file.separator"))));
        VisLabel up = new VisLabel(".." + System.getProperty("file.separator"));
        up.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (compass.cd("..")) reload();
            }
        });
        tree.add(new Tree.Node(up));

        for (File f : compass.ls())
            if (f.isDirectory()) {
                VisLabel label = new VisLabel(f.getName());
                label.setName(f.getName());
                label.addListener(new ClickListener() {
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        if (compass.cd(event.getListenerActor().getName())) reload();
                    }
                });
                tree.add(new Tree.Node(label));
            } else {
                VisTextButton button = new VisTextButton(f.getName());
                button.setName(f.getName());
                button.addListener(new ClickListener() {
                    @Override
                    public void clicked(InputEvent event, float x, float y) {
                        compass.open(event.getListenerActor().getName());
                    }
                });
                board.addActor(button);
            }
    }
}
