package com.github.neko250.ui.desktop;

import com.badlogic.gdx.Application;
import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import com.github.neko250.ui.GdxUI;

public class DesktopLauncher {
	public static void main (String[] arg) {
		createApplication();
	}

    private static Application createApplication() {
        final LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
        config.width = GdxUI.WIDTH;
        config.height = GdxUI.HEIGHT;
        config.resizable = false;
        config.x = -1;
        config.y = -1;
        config.title = "Compass";
        return new LwjglApplication(new GdxUI(), config);
    }
}
